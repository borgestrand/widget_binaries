Binary patch of Audio Widget ASIO driver and WidgetTest program

Date: 
20140429

Purpose: 
- To improve ASIO driver stability and introduce 64-bit functionality. 
- To allow UAC2 operation from any Windows program by means of
  http://vb-audio.pagesperso-orange.fr/Cable/


Not yet implemented:
- ASIO interface will freeze if left on during sleep/un-sleep cycle
- Build with newest libusbK
- Automatic installer


If you are on a 32-bit Windows computer:
- Verify that your installed ASIO driver is in C:\Program Files\Audio-Widget
  If not check if you have it installed and/or apply your destination folder 
  below. 
- Copy asiouac2_*.dll and WidgetTest.exe to C:\Program Files\Audio-Widget
- In C:\Program Files\Audio-Widget, copy either asiouac2_trace.dll or 
  asiouac2_release.dll to asiouac2.dll
- In case you use the trace version, view debug messages with DebugView
- Copy WidgetTest.exe to C:\Program Files\Audio-Widget
- Start WidgetTest.exe without arguments to see help message


If you are on a 64-bit Windows computer:
- Verify that your installed ASIO driver is in C:\Program Files (x86)\Audio-Widget
  If not check if you have it installed and/or apply your destination folder 
  below. Edit asio64.reg accordingly
- Apply asio64.reg
- Copy asiouac2_*.dll and WidgetTest.exe to C:\Program Files\Audio-Widget
- In C:\Program Files\Audio-Widget, copy either asiouac2_trace.dll or 
  asiouac2_release.dll to asiouac2.dll
- Repeat above two steps for 64-bit builds.
- In case you use the trace version, view debug messages with DebugView
- Copy WidgetTest.exe and WidgetTest64.exe to C:\Program Files (x86)\Audio-Widget
- Start WidgetTest.exe or WidgetTest64.exe without arguments to see help message

