Test setup on Windows 7, tested on 32 and 65-bit OS.


1 - Install Atmel Flip 3.4.5 from 
    http://www.atmel.com/dyn/products/tools_card.asp?tool_id=3886

2 - Copy files from Add_to_flip345_bin.zip to folder for Atmel\Flip 3.4.5\bin folder

3 - Download a signed driver Atmel DFU driver from:
    http://www.avrfreaks.net/index.php?module=Freaks%20Files&func=viewFile&id=3842&showinfo=1
    or Atmel_DFU_64_driver

4 - Start, Run, hdwwiz, Install manually, Show All, Have Disk, 
    point to where the DFU driver was saved (above file), choose AT32UC3A3, Next, Next, Install, 

5 - Reboot (may or may not be necessary)

6 - Ignore any messages about lacking drivers for "DG8SAQ-I2C"

7 - Go to Atmel\Flip 3.4.5\bin folder and run test.bat to test units

